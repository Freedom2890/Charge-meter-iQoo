package com.checksac.app;

import android.app.job.JobInfo;
import android.app.job.JobParameters;
import android.app.job.JobScheduler;
import android.app.job.JobService;
import android.content.ComponentName;
import android.content.Context;
import android.content.SharedPreferences;

/**
 * Bo danh thuc luc cam sac. Khi chua cam sac, app KHONG chay gi ca: chi co 1 job
 * (requiresCharging) do he thong giu. Cam sac -> he thong goi job nay -> bat ChargeService.
 * Rut sac -> ChargeService tu tat va dat lai job cho lan cam sac sau.
 */
public class ChargeJobService extends JobService {

    private static final int JOB_ID = 6001;

    static void schedule(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js == null) return;
            JobInfo info = new JobInfo.Builder(JOB_ID, new ComponentName(c, ChargeJobService.class))
                    .setRequiresCharging(true)
                    .setPersisted(true)     // song sot qua khoi dong lai (can RECEIVE_BOOT_COMPLETED)
                    .build();
            js.schedule(info);
        } catch (Exception ignored) {
        }
    }

    static void cancel(Context c) {
        try {
            JobScheduler js = (JobScheduler) c.getSystemService(Context.JOB_SCHEDULER_SERVICE);
            if (js != null) js.cancel(JOB_ID);
        } catch (Exception ignored) {
        }
    }

    @Override
    public boolean onStartJob(JobParameters params) {
        SharedPreferences p = getSharedPreferences(ChargeService.PREFS, MODE_PRIVATE);
        if (p.getBoolean(ChargeService.KEY_ENABLED, false) && PowerReader.read(this).plugged) {
            ChargeService.startFromBackground(this);
        }
        ChargeWidget.refresh(this);
        return false;   // xong ngay, khong giu tien trinh
    }

    @Override
    public boolean onStopJob(JobParameters params) {
        return false;
    }
}
