package com.checksac.app;

import android.app.Activity;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.ColorStateList;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.os.PowerManager;
import android.provider.Settings;
import android.text.SpannableString;
import android.text.Spanned;
import android.text.style.RelativeSizeSpan;
import android.view.Gravity;
import android.view.View;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.SeekBar;
import android.widget.TextView;
import android.widget.Toast;

import java.util.Locale;

public class MainActivity extends Activity {

    private static final int GREEN = 0xFF00C853;
    private static final int RED = 0xFFFF5252;

    private SharedPreferences prefs;
    private TextView toggle, tvState, tvPower, tvDetail, btnBattery, btnOv;
    private final Handler handler = new Handler(Looper.getMainLooper());

    private final Runnable live = new Runnable() {
        @Override public void run() {
            updateLive();
            handler.postDelayed(this, 1000);
        }
    };

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        prefs = getSharedPreferences(ChargeService.PREFS, MODE_PRIVATE);
        buildUi();
    }

    private void buildUi() {
        ScrollView scroll = new ScrollView(this);
        scroll.setFillViewport(true);
        scroll.setBackgroundColor(0xFF0D0F12);
        scroll.setOnApplyWindowInsetsListener((v, ins) -> {
            v.setPadding(ins.getSystemWindowInsetLeft(), ins.getSystemWindowInsetTop(),
                    ins.getSystemWindowInsetRight(), ins.getSystemWindowInsetBottom());
            return ins;
        });

        LinearLayout root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setGravity(Gravity.CENTER);
        root.setPadding(dp(24), dp(24), dp(24), dp(24));
        scroll.addView(root, new FrameLayout.LayoutParams(
                FrameLayout.LayoutParams.MATCH_PARENT, FrameLayout.LayoutParams.MATCH_PARENT));

        TextView title = text("⚡ Check Sạc", 30, 0xFFFFFFFF, true);
        root.addView(title, lp(-2, -2, 0));

        TextView sub = text("Đo công suất sạc thực tế", 14, 0xFF8A94A0, false);
        root.addView(sub, lp(-2, -2, dp(4)));

        tvPower = text("-- W", 48, 0xFFFFD60A, true);
        root.addView(tvPower, lp(-2, -2, dp(28)));

        tvDetail = text("", 14, 0xFF8A94A0, false);
        root.addView(tvDetail, lp(-2, -2, dp(2)));

        toggle = new TextView(this);
        toggle.setGravity(Gravity.CENTER);
        toggle.setTextSize(44);
        toggle.setTypeface(Typeface.DEFAULT_BOLD);
        toggle.setClickable(true);
        toggle.setOnClickListener(v -> onToggleClicked());
        root.addView(toggle, lp(dp(220), dp(220), dp(28)));

        tvState = text("", 16, 0xFFFFFFFF, true);
        root.addView(tvState, lp(-2, -2, dp(20)));

        TextView hint = text("Công suất hiện qua lớp phủ nổi và Widget khi đang cắm sạc.\n"
                + "Rút sạc là ứng dụng tắt hẳn, không chạy ngầm. Cắm sạc lại sẽ tự bật.", 13, 0xFF6B7580, false);
        root.addView(hint, lp(-2, -2, dp(10)));

        btnBattery = text("", 13, 0xFF9AA4AF, false);
        btnBattery.setPadding(dp(16), dp(10), dp(16), dp(10));
        GradientDrawable bd = new GradientDrawable();
        bd.setCornerRadius(dp(20));
        bd.setStroke(dp(1), 0xFF3A424B);
        btnBattery.setBackground(bd);
        btnBattery.setOnClickListener(v -> {
            try {
                startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
            } catch (Exception e) {
                Toast.makeText(this, "Không mở được cài đặt tối ưu pin", Toast.LENGTH_SHORT).show();
            }
        });
        root.addView(btnBattery, lp(-2, -2, dp(18)));

        // ---- Lop phu noi tren thanh trang thai ----
        TextView ovTitle = text("Lớp phủ nổi (số to trên màn hình)", 15, 0xFFFFFFFF, true);
        root.addView(ovTitle, lp(-2, -2, dp(28)));

        btnOv = text("", 13, 0xFF9AA4AF, false);
        btnOv.setPadding(dp(16), dp(10), dp(16), dp(10));
        GradientDrawable od = new GradientDrawable();
        od.setCornerRadius(dp(20));
        od.setStroke(dp(1), 0xFF3A424B);
        btnOv.setBackground(od);
        btnOv.setOnClickListener(v -> {
            boolean cur = prefs.getBoolean(ChargeService.KEY_OVERLAY, false);
            if (cur) {
                prefs.edit().putBoolean(ChargeService.KEY_OVERLAY, false).apply();
            } else {
                prefs.edit().putBoolean(ChargeService.KEY_OVERLAY, true).apply();
                if (!Settings.canDrawOverlays(this)) {
                    Toast.makeText(this, "Hãy cấp quyền \"Hiển thị trên ứng dụng khác\" cho Check Sạc",
                            Toast.LENGTH_LONG).show();
                    try {
                        startActivity(new Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION,
                                Uri.parse("package:" + getPackageName())));
                    } catch (Exception ignored) { }
                }
            }
            updateOvText();
            syncService();
        });
        root.addView(btnOv, lp(-2, -2, dp(10)));

        addSlider(root, "Cỡ chữ", 10, 40, 18, ChargeService.KEY_OV_SIZE, "");
        addSlider(root, "Vị trí ngang", 0, 100, 30, ChargeService.KEY_OV_X, "%");
        addSlider(root, "Vị trí dọc", 0, 60, 0, ChargeService.KEY_OV_Y, " dp");

        TextView ovHint = text("Bật chức năng + lớp phủ, kéo thanh trượt để chỉnh vị trí/cỡ chữ "
                + "(khi đang mở app luôn hiện xem thử). Đặt ở chỗ trống giữa đồng hồ và các biểu tượng.",
                12, 0xFF6B7580, false);
        root.addView(ovHint, lp(-2, -2, dp(14)));

        String ver = "";
        try { ver = getPackageManager().getPackageInfo(getPackageName(), 0).versionName; }
        catch (Exception ignored) { }
        TextView tvVer = text("Phiên bản " + ver, 12, 0xFF4A535C, false);
        root.addView(tvVer, lp(-2, -2, dp(22)));

        setContentView(scroll);
    }

    private void updateOvText() {
        boolean on = prefs.getBoolean(ChargeService.KEY_OVERLAY, false);
        if (!on) {
            btnOv.setText("Lớp phủ nổi: TẮT (nhấn để bật)");
        } else if (!Settings.canDrawOverlays(this)) {
            btnOv.setText("Lớp phủ nổi: BẬT nhưng CHƯA CẤP QUYỀN (nhấn để tắt)");
        } else {
            btnOv.setText("Lớp phủ nổi: BẬT (nhấn để tắt)");
        }
    }

    private void addSlider(LinearLayout root, String label, int min, int max, int def,
                           String key, String unit) {
        int cur = prefs.getInt(key, def);
        TextView lbl = text(label + ": " + cur + unit, 13, 0xFF9AA4AF, false);
        root.addView(lbl, lp(-2, -2, dp(12)));
        SeekBar sb = new SeekBar(this);
        sb.setMin(min);
        sb.setMax(max);
        sb.setProgress(cur);
        sb.setProgressTintList(ColorStateList.valueOf(0xFFFFD60A));
        sb.setThumbTintList(ColorStateList.valueOf(0xFFFFD60A));
        sb.setOnSeekBarChangeListener(new SeekBar.OnSeekBarChangeListener() {
            @Override public void onProgressChanged(SeekBar s, int v, boolean fromUser) {
                lbl.setText(label + ": " + v + unit);
                prefs.edit().putInt(key, v).apply();
                ChargeService.poke();
            }
            @Override public void onStartTrackingTouch(SeekBar s) { }
            @Override public void onStopTrackingTouch(SeekBar s) { }
        });
        root.addView(sb, lp(-1, -2, dp(2)));
    }


    @Override
    protected void onResume() {
        super.onResume();
        boolean on = prefs.getBoolean(ChargeService.KEY_ENABLED, false);
        applyToggleUi(on);
        updateOvText();
        ChargeService.preview = true;
        syncService();
        PowerManager pm = (PowerManager) getSystemService(Context.POWER_SERVICE);
        boolean ignoring = pm != null && pm.isIgnoringBatteryOptimizations(getPackageName());
        btnBattery.setText(ignoring
                ? "✓ Đã cho phép chạy nền ổn định"
                : "Cho phép chạy nền ổn định (tắt tối ưu pin)");
        handler.post(live);
    }

    @Override
    protected void onPause() {
        handler.removeCallbacks(live);
        ChargeService.preview = false;
        ChargeService.poke();
        super.onPause();
    }

    private void onToggleClicked() {
        boolean now = !prefs.getBoolean(ChargeService.KEY_ENABLED, false);
        if (!now) {
            prefs.edit().putBoolean(ChargeService.KEY_ENABLED, false).apply();
            ChargeJobService.cancel(this);
            ChargeService.stop(this);
            applyToggleUi(false);
            return;
        }
        prefs.edit().putBoolean(ChargeService.KEY_ENABLED, true).apply();
        syncService();
        applyToggleUi(true);
    }

    /**
     * Chi cho dich vu chay khi: dang cam sac, hoac dang mo app va bat overlay (xem thu).
     * Neu chua cam sac thi chi dat bo danh thuc luc cam sac (he thong giu, app khong chay gi).
     */
    private void syncService() {
        if (!prefs.getBoolean(ChargeService.KEY_ENABLED, false)) return;
        boolean plugged = PowerReader.read(this).plugged;
        boolean previewOv = prefs.getBoolean(ChargeService.KEY_OVERLAY, false)
                && Settings.canDrawOverlays(this);
        if (plugged || previewOv) {
            try { ChargeService.start(this); } catch (Exception ignored) { }
        } else {
            ChargeService.poke();   // neu dang chay de xem thu ma khong con can -> tu tat
        }
        if (!plugged) ChargeJobService.schedule(this);
    }

    private void applyToggleUi(boolean on) {
        String big = on ? "BẬT" : "TẮT";
        String small = on ? "\nĐang hoạt động\nNhấn để tắt" : "\nĐã vô hiệu hóa\nNhấn để bật";
        SpannableString ss = new SpannableString(big + small);
        ss.setSpan(new RelativeSizeSpan(0.34f), big.length(), ss.length(),
                Spanned.SPAN_EXCLUSIVE_EXCLUSIVE);
        toggle.setText(ss);

        GradientDrawable g = new GradientDrawable();
        g.setShape(GradientDrawable.OVAL);
        if (on) {
            g.setColor(GREEN);
            g.setStroke(dp(6), 0xFF69F0AE);
            toggle.setTextColor(0xFF04230F);
        } else {
            g.setColor(0xFF1B1F24);
            g.setStroke(dp(6), RED);
            toggle.setTextColor(0xFFFF8A80);
        }
        toggle.setBackground(g);

        ChargeWidget.refresh(this);
        tvState.setText(on ? "● Chức năng đang BẬT" : "● Chức năng đang TẮT");
        tvState.setTextColor(on ? GREEN : RED);
    }

    private void updateLive() {
        PowerReader.Reading r = PowerReader.read(this);
        if (!r.plugged) {
            tvPower.setText("-- W");
            tvDetail.setText("Chưa cắm sạc");
        } else if (!r.valid) {
            tvPower.setText("-- W");
            tvDetail.setText("Máy không cung cấp dòng sạc");
        } else {
            tvPower.setText(String.format(Locale.US, "%.1f W", r.watts));
            tvDetail.setText(String.format(Locale.US, "%d mA · %.2f V",
                    Math.round(r.milliAmps), r.volts));
        }
    }

    // ---- helpers ----
    private TextView text(String s, int sp, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s);
        t.setTextSize(sp);
        t.setTextColor(color);
        t.setGravity(Gravity.CENTER);
        if (bold) t.setTypeface(Typeface.DEFAULT_BOLD);
        return t;
    }

    private LinearLayout.LayoutParams lp(int w, int h, int topMargin) {
        LinearLayout.LayoutParams p = new LinearLayout.LayoutParams(w, h);
        p.topMargin = topMargin;
        p.gravity = Gravity.CENTER_HORIZONTAL;
        return p;
    }

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }
}
