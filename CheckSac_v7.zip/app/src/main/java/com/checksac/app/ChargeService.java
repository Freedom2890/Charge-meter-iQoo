package com.checksac.app;

import android.app.AlarmManager;
import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.IntentFilter;
import android.content.SharedPreferences;
import android.content.pm.ServiceInfo;
import android.graphics.PixelFormat;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Handler;
import android.os.IBinder;
import android.os.Looper;
import android.os.PowerManager;
import android.os.SystemClock;
import android.provider.Settings;
import android.view.Gravity;
import android.view.View;
import android.view.WindowManager;
import android.widget.TextView;

import java.util.Locale;

/**
 * Dich vu foreground cuc nhe, KHONG hien thong bao / icon tren thanh trang thai.
 * Chi hien cong suat qua: lop phu noi (overlay) va Widget.
 *
 *  - CHI chay khi dang cam sac (hoac khi dang mo app de xem thu overlay).
 *  - Rut sac -> tu dung hoan toan (go overlay, huy vong lap, stopSelf), khong con chay ngam.
 *  - Khi dich vu da tat, ChargeJobService (JobScheduler, do he thong giu) se danh thuc lai
 *    dung luc cam sac lan sau.
 */
public class ChargeService extends Service {

    static final String PREFS = "cfg";
    static final String KEY_ENABLED = "enabled";
    static final String KEY_OVERLAY = "overlay";
    static final String KEY_OV_SIZE = "ov_size";
    static final String KEY_OV_X = "ov_x";
    static final String KEY_OV_Y = "ov_y";

    /** Dich vu dang chay (cung tien trinh voi Activity) de Activity goi cap nhat nhanh. */
    static volatile ChargeService instance;
    /** Dang mo app: hien overlay xem thu de chinh vi tri/co chu. */
    static volatile boolean preview = false;

    // Kenh thong bao im lang tuyet doi (IMPORTANCE_MIN): khong icon tren status bar, khong am thanh.
    // Android bat buoc foreground service phai co 1 notification; app KHONG xin quyen
    // POST_NOTIFICATIONS nen thong bao nay khong hien ra o dau ca.
    private static final String CH_QUIET = "quiet_v1";
    private static final int NID = 1;
    private static final long POLL_MS = 2000;

    private final Handler handler = new Handler(Looper.getMainLooper());
    private boolean screenOn = true;
    private boolean unplugHint = false;   // vua nhan POWER_DISCONNECTED (phong khi sticky chua kip cap nhat)
    private boolean stopping = false;
    private String lastKey = "";
    private WindowManager wm;
    private TextView ov;
    private boolean ovAdded = false;
    private String lastOv = "";

    private final Runnable tick = new Runnable() {
        @Override public void run() { refresh(); }
    };

    private final BroadcastReceiver receiver = new BroadcastReceiver() {
        @Override public void onReceive(Context context, Intent intent) {
            String a = intent.getAction();
            if (Intent.ACTION_SCREEN_OFF.equals(a)) screenOn = false;
            else if (Intent.ACTION_SCREEN_ON.equals(a)) screenOn = true;
            else if (Intent.ACTION_POWER_DISCONNECTED.equals(a)) unplugHint = true;
            else if (Intent.ACTION_POWER_CONNECTED.equals(a)) unplugHint = false;
            refresh();
        }
    };

    static void start(Context c) {
        c.startForegroundService(new Intent(c, ChargeService.class));
    }

    static void stop(Context c) {
        c.stopService(new Intent(c, ChargeService.class));
    }

    /**
     * Khoi dong dich vu tu nen (JobService/BootReceiver). Neu he thong tu choi khoi dong
     * foreground service tu nen thi du phong bang bao thuc chinh xac (duoc mien han che).
     */
    static void startFromBackground(Context c) {
        try {
            start(c);
        } catch (Exception e) {
            restartViaAlarm(c);
        }
    }

    static void restartViaAlarm(Context c) {
        try {
            SharedPreferences p = c.getSharedPreferences(PREFS, MODE_PRIVATE);
            if (!p.getBoolean(KEY_ENABLED, false)) return;
            AlarmManager am = (AlarmManager) c.getSystemService(ALARM_SERVICE);
            if (am == null) return;
            PendingIntent pi = PendingIntent.getForegroundService(c, 1,
                    new Intent(c, ChargeService.class),
                    PendingIntent.FLAG_IMMUTABLE | PendingIntent.FLAG_UPDATE_CURRENT);
            long at = SystemClock.elapsedRealtime() + 1000;
            if (Build.VERSION.SDK_INT < 31 || am.canScheduleExactAlarms()) {
                am.setExactAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.ELAPSED_REALTIME_WAKEUP, at, pi);
            }
        } catch (Exception ignored) {
        }
    }

    @Override
    public void onCreate() {
        super.onCreate();
        instance = this;
        wm = (WindowManager) getSystemService(WINDOW_SERVICE);
        createChannel();

        PowerManager pm = (PowerManager) getSystemService(POWER_SERVICE);
        screenOn = pm == null || pm.isInteractive();

        IntentFilter f = new IntentFilter();
        f.addAction(Intent.ACTION_SCREEN_ON);
        f.addAction(Intent.ACTION_SCREEN_OFF);
        f.addAction(Intent.ACTION_POWER_CONNECTED);
        f.addAction(Intent.ACTION_POWER_DISCONNECTED);
        if (Build.VERSION.SDK_INT >= 33) {
            registerReceiver(receiver, f, Context.RECEIVER_NOT_EXPORTED);
        } else {
            registerReceiver(receiver, f);
        }
    }

    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        // Bat buoc goi startForeground ngay sau startForegroundService
        Notification n = quietNotification();
        if (Build.VERSION.SDK_INT >= 34) {
            startForeground(NID, n, ServiceInfo.FOREGROUND_SERVICE_TYPE_SPECIAL_USE);
        } else {
            startForeground(NID, n);
        }

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (!p.getBoolean(KEY_ENABLED, false)) {
            shutdown();
            return START_NOT_STICKY;
        }
        unplugHint = false;
        refresh();
        return START_STICKY;
    }

    @Override
    public void onTaskRemoved(Intent rootIntent) {
        // Vuot tat app khoi da nhiem: chi tu bat lai neu dang cam sac
        if (PowerReader.read(this).plugged) restartViaAlarm(this);
        super.onTaskRemoved(rootIntent);
    }

    @Override
    public void onDestroy() {
        handler.removeCallbacks(tick);
        removeOverlay();
        instance = null;
        try { unregisterReceiver(receiver); } catch (Exception ignored) { }
        stopForeground(STOP_FOREGROUND_REMOVE);
        ChargeWidget.refresh(this);

        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (p.getBoolean(KEY_ENABLED, false)) {
            // Cho lan cam sac tiep theo (hoac tu bat lai neu bi he thong dung khi dang sac)
            ChargeJobService.schedule(this);
            if (!stopping && PowerReader.read(this).plugged) restartViaAlarm(this);
        }
        super.onDestroy();
    }

    @Override
    public IBinder onBind(Intent intent) { return null; }

    // ------------------------------------------------------------------

    static void poke() {
        ChargeService s = instance;
        if (s != null) s.refresh();
    }

    /** Tat han: go overlay, huy vong lap, dung dich vu -> khong con chay ngam. */
    private void shutdown() {
        stopping = true;
        handler.removeCallbacks(tick);
        removeOverlay();
        stopForeground(STOP_FOREGROUND_REMOVE);
        stopSelf();
    }

    private void refresh() {
        if (stopping) return;
        handler.removeCallbacks(tick);
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        PowerReader.Reading r = PowerReader.read(this);
        if (unplugHint) r.plugged = false;

        // Chay khi: dang cam sac, hoac dang mo app xem thu overlay. Con lai -> tat han.
        if (!p.getBoolean(KEY_ENABLED, false) || !(r.plugged || preview)) {
            shutdown();
            return;
        }

        boolean active = r.plugged && screenOn;
        updateOverlay(r, active);
        if (active) {
            String key = r.valid ? String.format(Locale.US, "p%.1f", r.watts) : "p?";
            if (!key.equals(lastKey)) {
                lastKey = key;
                ChargeWidget.refresh(this);
            }
            handler.postDelayed(tick, POLL_MS);   // chi lap khi dang sac + man hinh bat
        } else {
            lastKey = "";
            if (screenOn) ChargeWidget.refresh(this);
        }
    }


    // ------------------- Lop phu noi (overlay) -------------------

    private int dp(int v) {
        return Math.round(v * getResources().getDisplayMetrics().density);
    }

    private void updateOverlay(PowerReader.Reading r, boolean active) {
        SharedPreferences p = getSharedPreferences(PREFS, MODE_PRIVATE);
        boolean want = p.getBoolean(KEY_ENABLED, false)
                && p.getBoolean(KEY_OVERLAY, false)
                && Settings.canDrawOverlays(this)
                && screenOn
                && (active || preview);
        if (!want) {
            removeOverlay();
            return;
        }

        String text;
        if (!r.plugged) text = "--W";
        else if (!r.valid) text = "?W";
        else if (r.watts >= 10) text = String.format(Locale.US, "%.0fW", r.watts);
        else text = String.format(Locale.US, "%.1fW", r.watts);

        int size = p.getInt(KEY_OV_SIZE, 18);
        int xp = p.getInt(KEY_OV_X, 30);
        int yd = p.getInt(KEY_OV_Y, 0);
        String key = text + "|" + size + "|" + xp + "|" + yd;
        if (ovAdded && key.equals(lastOv)) return;
        lastOv = key;

        try {
            if (ov == null) {
                ov = new TextView(this);
                ov.setTypeface(Typeface.create("sans-serif-condensed", Typeface.BOLD));
                ov.setTextColor(0xFFFFD60A);
                ov.setIncludeFontPadding(false);
                ov.setPadding(dp(6), dp(2), dp(6), dp(2));
                GradientDrawable g = new GradientDrawable();
                g.setColor(0x99000000);
                g.setCornerRadius(dp(8));
                ov.setBackground(g);
            }
            ov.setTextSize(size);
            ov.setText(text);
            ov.measure(View.MeasureSpec.UNSPECIFIED, View.MeasureSpec.UNSPECIFIED);
            int w = ov.getMeasuredWidth();
            int sw = getResources().getDisplayMetrics().widthPixels;

            WindowManager.LayoutParams lp = new WindowManager.LayoutParams(
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.WRAP_CONTENT,
                    WindowManager.LayoutParams.TYPE_APPLICATION_OVERLAY,
                    WindowManager.LayoutParams.FLAG_NOT_FOCUSABLE
                            | WindowManager.LayoutParams.FLAG_NOT_TOUCHABLE
                            | WindowManager.LayoutParams.FLAG_LAYOUT_IN_SCREEN
                            | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS,
                    PixelFormat.TRANSLUCENT);
            lp.gravity = Gravity.TOP | Gravity.START;
            lp.x = Math.round(xp / 100f * Math.max(0, sw - w));
            lp.y = dp(yd);
            if (Build.VERSION.SDK_INT >= 30) {
                lp.layoutInDisplayCutoutMode =
                        WindowManager.LayoutParams.LAYOUT_IN_DISPLAY_CUTOUT_MODE_ALWAYS;
            }
            if (!ovAdded) {
                wm.addView(ov, lp);
                ovAdded = true;
            } else {
                wm.updateViewLayout(ov, lp);
            }
        } catch (Exception e) {
            ovAdded = false;
            lastOv = "";
        }
    }

    private void removeOverlay() {
        if (ovAdded && ov != null) {
            try { wm.removeView(ov); } catch (Exception ignored) { }
        }
        ovAdded = false;
        lastOv = "";
    }

    private void createChannel() {
        NotificationManager nm = (NotificationManager) getSystemService(NOTIFICATION_SERVICE);
        try { nm.deleteNotificationChannel("power_v1"); } catch (Exception ignored) { }
        try { nm.deleteNotificationChannel("power_v2"); } catch (Exception ignored) { }
        try { nm.deleteNotificationChannel("idle_v1"); } catch (Exception ignored) { }
        NotificationChannel ch = new NotificationChannel(
                CH_QUIET, "Dịch vụ nền (ẩn)", NotificationManager.IMPORTANCE_MIN);
        ch.setShowBadge(false);
        ch.setSound(null, null);
        ch.enableVibration(false);
        ch.enableLights(false);
        ch.setLockscreenVisibility(Notification.VISIBILITY_SECRET);
        nm.createNotificationChannel(ch);
    }

    /** Thong bao toi thieu bat buoc cua foreground service: im lang, an, khong icon tren status bar. */
    private Notification quietNotification() {
        return new Notification.Builder(this, CH_QUIET)
                .setSmallIcon(R.drawable.ic_idle)
                .setContentTitle("Check Sạc")
                .setOngoing(true)
                .setShowWhen(false)
                .setOnlyAlertOnce(true)
                .setLocalOnly(true)
                .setVisibility(Notification.VISIBILITY_SECRET)
                .setCategory(Notification.CATEGORY_SERVICE)
                .build();
    }
}
