package com.checksac.app;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;

/**
 * Sau khi may khoi dong / cap nhat app, neu cong tac dang BAT:
 *  - dat bo danh thuc luc cam sac (JobScheduler);
 *  - neu luc do dang cam sac san thi bat dich vu luon. Neu chua cam sac thi KHONG chay gi.
 */
public class BootReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        SharedPreferences p = context.getSharedPreferences(ChargeService.PREFS, Context.MODE_PRIVATE);
        if (!p.getBoolean(ChargeService.KEY_ENABLED, false)) return;
        ChargeJobService.schedule(context);
        if (PowerReader.read(context).plugged) {
            ChargeService.startFromBackground(context);
        }
    }
}
